## Welcome to Todo-List 

It's a JavaScript Based small Project with allowing features of LocalStorage to use properly. How we can save Data into localStorage and delete them . Also We use DOM Scripting & Event Listener feature of JS. 

### For an idea see this : 
[Demo](https://susanta96.github.io/Todo-list-JS) 


``` 
Still we also have to work more on this to get the proper completed task section






